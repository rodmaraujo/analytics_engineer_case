from dagster import op, get_dagster_logger
from dagster_dbt import DbtCliResource


@op(required_resource_keys={"dbt"})
def run_dbt_models(context):
    logger = get_dagster_logger()

    logger.info("Starting dbt run...")

    # Start dbt run
    invocation = context.resources.dbt.cli(["run"], context=context)

    # Stream logs (Dagster versions before 1.7 use this API)
    for raw_event in invocation.stream_raw_events():
        logger.info(raw_event)

    # Wait until DBT finishes
    result = invocation.wait()

    # NÃO usa result.return_code 
    if result is None:
        
        logger.info("dbt run completed with no returned result object.")
    else:
        logger.info("dbt run finished. Result object received.")

    logger.info("dbt run completed successfully!")

    
    return "DBT_DONE"
